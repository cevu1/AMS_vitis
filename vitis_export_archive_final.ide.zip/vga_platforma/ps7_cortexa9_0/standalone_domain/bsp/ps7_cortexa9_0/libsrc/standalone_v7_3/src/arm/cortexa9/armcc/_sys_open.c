#include "xil_types.h"
/* Stub for open sys-call */
__weak s32 _sys_open(const char8* name, s32 openmode)
{
   return 0;
}
