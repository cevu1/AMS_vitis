#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "sine_and_saw_samples.h"
#include "rgb_and_greyscale_values.h"

//biblioteke za rad sa periferijama - switches, buttons i leds
#include "xil_io.h"
#include "xparameters.h"
#include "sleep.h"

// bilioteke za rad sa timer-om
#include "xil_exception.h"
#include "xscugic.h"

// biblioteke za rad sa VGA
#include "xil_cache.h"
#include "xil_mmu.h"
#include "xbasic_types.h"

//makroi za upravljanje periferijama - sw, btn i leds
#define LED_BASEADDR 0x41200000
#define BUTTON_BASEADDR 0x41210000
#define SWITCH_BASEADDR 0x41220000

//makroi za upravljanje periferijama - timer0, prekopirano sa vezbi, AMS, AXI TIMER0:
// Timer base Addres, can also be found in address editor in vivado
// but this way it is automaticaly generated in xparameters.h file
// when platform project is created
#define TIMER_BASEADDR XPAR_AXI_TIMER_0_BASEADDR
// Can also be found in xparameters.h file. Every interrupt has its number
#define TIMER_INTERRUPT_ID XPAR_FABRIC_AXI_TIMER_0_INTERRUPT_INTR
// Processor core also has its own device ID which is used to enable
// interrupts
#define INTC_DEVICE_ID XPAR_PS7_SCUGIC_0_DEVICE_ID
// REGISTER CONSTANTS used to address correct registers
// inside AXI timer IP
#define XIL_AXI_TIMER_TCSR_OFFSET 0x0
#define XIL_AXI_TIMER_TLR_OFFSET 0x4
#define XIL_AXI_TIMER_TCR_OFFSET 0x8
// Constants used to setup AXI Timer registers
#define XIL_AXI_TIMER_CSR_CASC_MASK 0x00000800
#define XIL_AXI_TIMER_CSR_ENABLE_ALL_MASK 0x00000400
#define XIL_AXI_TIMER_CSR_ENABLE_PWM_MASK 0x00000200
#define XIL_AXI_TIMER_CSR_INT_OCCURED_MASK 0x00000100
#define XIL_AXI_TIMER_CSR_ENABLE_TMR_MASK 0x00000080
#define XIL_AXI_TIMER_CSR_ENABLE_INT_MASK 0x00000040
#define XIL_AXI_TIMER_CSR_LOAD_MASK 0x00000020
#define XIL_AXI_TIMER_CSR_AUTO_RELOAD_MASK 0x00000010
#define XIL_AXI_TIMER_CSR_EXT_CAPTURE_MASK 0x00000008
#define XIL_AXI_TIMER_CSR_EXT_GENERATE_MASK 0x00000004
#define XIL_AXI_TIMER_CSR_DOWN_COUNT_MASK 0x00000002
#define XIL_AXI_TIMER_CSR_CAPTURE_MODE_MASK 0x00000001

// Funtion Prototypes
u32 Setup_Interrupt(u32 DeviceId, Xil_InterruptHandler Handler, u32 interrupt_ID);
void Timer_Interrupt_Handler();
static void Setup_And_Start_Timer(unsigned int milliseconds);


void readBut();
u8 sineOrSaw();
void promena_switcha();
volatile int timer_intr_done = 0;
uint8_t button[2] = {0,0};
uint8_t last_button = 0;
uint8_t buttons = 0;
int switches = 0;
u8 odbirci = 65;

int sw1_old, sw1_new = 0;
volatile u8 trigger = 1;

volatile int f = 1;

int main()
{
	int status;
	int data;

    init_platform();

    Xil_DCacheDisable();
    Xil_ICacheDisable();

    u8 sin_ili_test;
    status = Setup_Interrupt(INTC_DEVICE_ID, (Xil_InterruptHandler)Timer_Interrupt_Handler, TIMER_INTERRUPT_ID);

    while(1)
    {

    	 if(trigger){
    	    switches = Xil_In32(SWITCH_BASEADDR);
    	    if(switches&0x2)
    	    {
    	    	for(u8 j = 56; j < 128 + 56; j++)
    	    	{
    	    	    for(u8 i = 96; i < 128 + 96; i++)
    	    	    {
    	    	    	Xil_Out16(XPAR_AXI_BRAM_CTRL_0_S_AXI_BASEADDR + (j*320+i)*2, (u16)grayscale_values[(j-56)*(128)+(i-96)]);
    	    	    }
    	    	}

    	   	}
    	    else
    	    {
    	    	for(u8 j = 56; j < 128 + 56; j++)
    	    	{
    	    	   for(u8 i = 96; i < 128 + 96; i++)
    	    	   {
    	    	   	   Xil_Out16(XPAR_AXI_BRAM_CTRL_0_S_AXI_BASEADDR + (j*320+i)*2, (u16)rgb_values[(j-56)*(128)+(i-96)]);
    	    	   }
    	    	}
    		}
    	}

    	promena_switcha();

    	sin_ili_test = sineOrSaw();
    	readBut();
    	xil_printf("f = %d\r\n", f);
    	xil_printf("button0 = %d\r\n", button[0]);
    	xil_printf("button1 = %d\r\n\r\n", button[1]);
    	unsigned int To = (unsigned int)(1000000/(f * odbirci));

    	if(sin_ili_test && f > 0)
    	{
			for(u8 i = 0; i < odbirci; i++)
			{
				unsigned int diodes_on = (unsigned int)(To * (sin_samples[i]/2));
				unsigned int diodes_off = To - diodes_on;

				Xil_Out32(LED_BASEADDR, 15);
				usleep(diodes_on);

				Xil_Out32(LED_BASEADDR, 0);
				usleep(diodes_off);
			}
    	}
    	else if(f > 0)
    	{
    		for(u8 i = 0; i < odbirci; i++)
    		{
    			unsigned int To = (unsigned int)(1000000/(f * odbirci));
    			unsigned int diodes_on = (unsigned int)(To * (saw_samples[i]));
    			unsigned int diodes_off = To - diodes_on;

    			Xil_Out32(LED_BASEADDR, 15);
    			usleep(diodes_on);

    			Xil_Out32(LED_BASEADDR, 0);
    			usleep(diodes_off);
    		}
    	}
    	else
    	{
    		Xil_Out32(LED_BASEADDR, 0);
    	}
    }

    cleanup_platform();
    return 0;
}

// Initialize Interrupt Controller
u32 Setup_Interrupt(u32 DeviceId, Xil_InterruptHandler Handler, u32 interrupt_ID)
{
	XScuGic_Config *IntcConfig;
	XScuGic INTCInst;
	int status;
	// Extracts informations about processor core based on its ID, and they are used to setup interrupts
	IntcConfig = XScuGic_LookupConfig(DeviceId);
	// Initializes processor registers using information extracted in the previous step
	status = XScuGic_CfgInitialize(&INTCInst, IntcConfig, IntcConfig->CpuBaseAddress);
	if(status != XST_SUCCESS) return XST_FAILURE;
	status = XScuGic_SelfTest(&INTCInst);
	if (status != XST_SUCCESS) return XST_FAILURE;
	// Connect Timer Handler And Enable Interrupt
	// The processor can have multiple interrupt sources, and we must setup trigger and priority
	// for the our interrupt. For this we are using interrupt ID.
	XScuGic_SetPriorityTriggerType(&INTCInst, interrupt_ID, 0xA8, 3);
	// Connects out interrupt with the appropriate ISR (Handler)
	status = XScuGic_Connect(&INTCInst, interrupt_ID, Handler, (void *)&INTCInst);
	if(status != XST_SUCCESS) return XST_FAILURE;
	// Enable interrupt for out device
	XScuGic_Enable(&INTCInst, interrupt_ID);
	//Two lines bellow enable exeptions
	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT, (Xil_ExceptionHandler)XScuGic_InterruptHandler,&INTCInst);
	Xil_ExceptionEnable();
	return XST_SUCCESS;
}

// Timer Interrupt Handler
/*void Timer_Interrupt_Handler()
{
	timer_intr_done = 1;
	return;
}*/

static void Setup_And_Start_Timer(unsigned int milliseconds)
{
	// Disable Timer Counter
	unsigned int timer_load;
	unsigned int zero = 0;
	unsigned int data = 0;
	// Line bellow is true if timer is working on 100MHz
	timer_load = zero - milliseconds*100000;
	// Disable timer/counter while configuration is in progress
	data = Xil_In32(TIMER_BASEADDR + XIL_AXI_TIMER_TCSR_OFFSET);
	Xil_Out32(TIMER_BASEADDR + XIL_AXI_TIMER_TCSR_OFFSET, (data & ~(XIL_AXI_TIMER_CSR_ENABLE_TMR_MASK)));
	// Set initial value in load register
	Xil_Out32(TIMER_BASEADDR + XIL_AXI_TIMER_TLR_OFFSET, timer_load);
	// Load initial value into counter from load register
	data = Xil_In32(TIMER_BASEADDR + XIL_AXI_TIMER_TCSR_OFFSET);
	Xil_Out32(TIMER_BASEADDR + XIL_AXI_TIMER_TCSR_OFFSET, (data | XIL_AXI_TIMER_CSR_LOAD_MASK));
	// Set LOAD0 bit from the previous step to zero
	data = Xil_In32(TIMER_BASEADDR + XIL_AXI_TIMER_TCSR_OFFSET);
	Xil_Out32(TIMER_BASEADDR + XIL_AXI_TIMER_TCSR_OFFSET, (data & ~(XIL_AXI_TIMER_CSR_LOAD_MASK)));
	// Enable interrupts and autoreload, reset should be zero
	Xil_Out32(TIMER_BASEADDR + XIL_AXI_TIMER_TCSR_OFFSET, (XIL_AXI_TIMER_CSR_ENABLE_INT_MASK | XIL_AXI_TIMER_CSR_AUTO_RELOAD_MASK));
	// Start Timer by setting enable signal
	data = Xil_In32(TIMER_BASEADDR + XIL_AXI_TIMER_TCSR_OFFSET);
	Xil_Out32(TIMER_BASEADDR + XIL_AXI_TIMER_TCSR_OFFSET, (data | XIL_AXI_TIMER_CSR_ENABLE_TMR_MASK));
}

void readBut()
{

	buttons = Xil_In8(BUTTON_BASEADDR);
	if(buttons != last_button)
	{
		last_button = buttons;
		button[0] = (buttons & 0x01) ? 1 : 0;
		button[1] = (buttons & 0x02) ? 1 : 0;

		if(button[0])
			f++;
		if(button[1])
			f--;
	}
}


u8 sineOrSaw()
{
	u8 sine = 1;									// sinusni

	switches = Xil_In32(SWITCH_BASEADDR);
	if(switches & 0x1)								// testerasti
	{
		sine = 0;
	}

	return sine;
}

void promena_switcha()
{
	trigger = 0;
	switches = Xil_In32(SWITCH_BASEADDR);
	sw1_new = switches&0x2;
	if(sw1_old != sw1_new)
	{
		trigger = 1;
		sw1_old = sw1_new;
	}
	sw1_old = sw1_new;
}
