-= SD card boot image =-

Platform: vga_platforma
Application: van_gogh_leds_sine_saw_wrapper

1. Copy the contents of this directory to an SD card
2. Set boot mode to SD
3. Insert SD card and turn board on
